**ÜBUNGSPROTOKOLL · VORLAGE**

**SYTB – Systemtechnik Betriebssysteme**

3\. Jahrgang · HTL Krems · Vorlage für dein wöchentliches Übungsprotokoll

| **Woche / Station** | **Datum**  |
|---------------------|------------|
| Woche 4             | 02.10.2026 |

Partnerarbeit mit (falls zutreffend): \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**1 · Aufgabenstellung**

*Worum ging es in dieser Einheit? Ein bis zwei Sätze reichen – z. B. Titel und Kernthema des Arbeitsblatts.*

Paketmanager und Prozesse

**2 · Ergebnisse**

*Screenshot(s) oder Beispiel-Ausgaben, die dein Ergebnis zeigen – z. B. ls -la deines Ordners, deine IP-Adresse, dein Levelstand in GameShell, der Name deines Snapshots. Screenshot einfach hier einfügen (Bild einfügen, oder per Copy-Paste).*

Aufgabe 1

1.sudo apt update zeigt die Sachen an die möglicherweise ein Update benötigen.

2.http://deb.debian.org/debian

3.weil sie davor nicht vorhanden waren.

<img src="images/image1.png" style="width:3.41667in;height:1.96875in" /><img src="images/image2.png" style="width:6.925in;height:2.34514in" />

4\.

<img src="images/image3.png" style="width:5.30208in;height:2.35486in" /> 5.

<img src="images/image4.png" style="width:6.925in;height:0.21597in" /> 6.

<img src="images/image5.png" style="width:2.16697in;height:2.02112in" />

7\. <img src="images/image6.png" style="width:6.53216in;height:0.41672in" />

<img src="images/image7.png" style="width:6.925in;height:0.53264in" />

8\. apt autoremove löscht alles was veraltet ist, aber schon erneuert wurde.

Aufgabe 2

1.Ja, seit Systemstart, 581, ja.

2.Ja, die PID ist genauso 581.

Da mein grep Befehl genauso ein Prozess ist wie cron.

3\. 582<img src="images/image8.png" style="width:6.925in;height:1.33958in" />

4\. <img src="images/image9.png" style="width:6.925in;height:1.75139in" />

Aufgabe 3

1\.

<img src="images/image10.png" style="width:3.89638in;height:0.73969in" />

2\.

<img src="images/image11.png" style="width:6.925in;height:1.93889in" />

3\.

<img src="images/image12.png" style="width:6.925in;height:1.30278in" />

4\.

<img src="images/image13.png" style="width:6.925in;height:0.27083in" />

<img src="images/image14.png" style="width:6.925in;height:1.98681in" />

5\.

<img src="images/image15.png" style="width:6.925in;height:2.28819in" />

<img src="images/image16.png" style="width:6.925in;height:0.42639in" />

**3 · Kontrollfragen & Antworten**

*Übernimm die Kontrollfragen aus dem Arbeitsblatt dieser Woche und beantworte sie hier in eigenen Worten.*

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Frage</strong></th>
<th><strong>Antwort</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>Warum musst du nach dem Anlegen oder Ändern einer Unit-Datei daemon-reload ausführen?</td>
<td>Damit die Prozesse neu ausgeführt werden und damit auch die Änderungen übernommen werden.</td>
</tr>
<tr class="even">
<td>Welche Zeile der Unit-Datei sorgt dafür, dass der Dienst nach dem Absturz wieder aufsteht? Und welche dafür, dass er beim Booten startet?</td>
<td><p>Booten ExecStart</p>
<p>Nach Absturz Restart</p></td>
</tr>
<tr class="odd">
<td>Wo liegen auf Debian Konfigurationsdateien, wo Programme aus Paketen, wo selbst geschriebene Programme – und wo landen die Meldungen deiner Dienste?</td>
<td><p>Meldungen Systemd-Journal</p>
<p>Konfig. etc/</p>
<p>Paketprog. usr/bin</p>
<p>Selbst geschrieben usr/local/bin</p></td>
</tr>
</tbody>
</table>

**4 · Reflexion**

*Was war heute am schwierigsten zu verstehen, und warum?*

Nichts, war jedoch eine gute Wiederholung.

*Was hast du heute neu gelernt, das dir vorher nicht klar war?*

Programm schreiben.

*Wobei hättest du dir mehr Zeit oder Hilfe gewünscht?*

Nirgendwo.
