**ÜBUNGSPROTOKOLL · VORLAGE**

**SYTB – Systemtechnik Betriebssysteme**

3\. Jahrgang · HTL Krems · Vorlage für dein wöchentliches Übungsprotokoll

| **Woche / Station** | **Datum**  |
|---------------------|------------|
| Woche 3             | 25.09.2026 |

Partnerarbeit mit (falls zutreffend): \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Wie diese Vorlage gemeint ist  
**In SYTB gibt es keine Hausübungen, keine Abgabefristen und kein Einsammeln (siehe Leitfaden, Abschnitt 5). Dieses Protokoll ist dein eigenes Gedächtnisprotokoll – es hilft dir, den Stoff zu festigen, und ist die Grundlage, falls wir gemeinsam draufschauen. Speichere es nach dem im jeweiligen Arbeitsblatt genannten Schema, z. B. SYTB_W02_Mustermann, und behalte es einfach bei dir.

**1 · Aufgabenstellung**

*Worum ging es in dieser Einheit? Ein bis zwei Sätze reichen – z. B. Titel und Kernthema des Arbeitsblatts.*

Rechte, Gruppen und Mounts.

**2 · Durchgeführte Schritte & Befehle**

*Trage die wichtigsten Befehle ein, die du ausgeführt hast, und was dabei passiert ist. Ergänze bei Bedarf weitere Zeilen.*

Die Schritte sind unten angegeben.

**3 · Ergebnisse**

*Screenshot(s) oder Beispiel-Ausgaben, die dein Ergebnis zeigen – z. B. ls -la deines Ordners, deine IP-Adresse, dein Levelstand in GameShell, der Name deines Snapshots. Screenshot einfach hier einfügen (Bild einfügen, oder per Copy-Paste).*

Aufgabe 1

Szenario 1: fehlende Execution Rechte nur rw- statt rwx für Owner

chmod +x start.sh

<img src="images/image1.png" style="width:4.52146in;height:0.37505in" />

Szenario 2:

chmod +r notiz.txt

chmod u+w notiz.txt

<img src="images/image2.png" style="width:4.74024in;height:0.38547in" />

Szenario 3: fehlende Execution Rechte nur drw- statt drwx

chmod +x projekt/

<img src="images/image3.png" style="width:5.32366in;height:1.61481in" />

Szenario 4: Ich war bereits der Besitzer der Datei.

<img src="images/image4.png" style="width:5.06321in;height:0.37505in" />

<img src="images/image5.png" style="width:3.88596in;height:0.54174in" />

Szenario 5: teambericht.txt wird mir auch bei ls -la nicht angezeigt und die Gruppe team existiert nicht.

<img src="images/image6.png" style="width:5.2299in;height:1.52105in" />

Su - groupadd team usermod -aG team user exit logout

<img src="images/image7.png" style="width:6.56342in;height:0.37505in" />

Szenario 6:

<img src="images/image8.png" style="width:5.24031in;height:1.72941in" />

Aufgabe 2

1.lsblk ausführen

<img src="images/image9.png" style="width:3.63592in;height:1.18767in" />

2.df -h ausführen

<img src="images/image10.png" style="width:6.85512in;height:1.87526in" />

17Gb

3.Vergleich MOUNTPOINT und Mounted

df -h ist detailierter

Aufgabe 3

a)mkdir projekt-team chgrp team projekt-team/ chmod 660 projekt-team/

<img src="images/image11.png" style="width:5.26115in;height:1.67732in" />

b\)

1.rwxr-----

chmod 740 test.txt

<img src="images/image12.png" style="width:4.64648in;height:0.36463in" />

2.rw-rw-r—

chmod 664 test.txt

<img src="images/image13.png" style="width:4.61523in;height:0.41672in" />

3.rwx------

chmod 700 test.txt

<img src="images/image14.png" style="width:4.44854in;height:0.38547in" />

**4 · Kontrollfragen & Antworten**

*Übernimm die Kontrollfragen aus dem Arbeitsblatt dieser Woche und beantworte sie hier in eigenen Worten.*

| **Frage**                                                                                           | **Antwort**                                                                                                         |
|-----------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------|
| Was bedeutet die Ausgabe rwxr-xr—bei ls -la?                                                        | Der Owner darf alles, die Gruppe darf lesen und ausführen und der die Anderen dürfen nur lesen.                     |
| Warum ist chmod 777 fast immer die falsche Lösung?                                                  | Weil dadurch jeder Zugriff auf alles hat.                                                                           |
| Was zeigt die Spalte MOUNTPOINT bei lsblk?                                                          | Wo die Festplatte angehängt wurde.                                                                                  |
| Was ist der Unterschied zwischen einer Umleitung ( \> ) und einer Pipe ( \| )?                      | Die Umleitung überschreibt die andere Datei und die Pipe gibt das Ergebnis eines Befehls an den nächsten weiter.    |
| Warum zeigt ls eine Datei wie .geheim.conf nicht an?                                                | Weil nur mit -la die „geheimen“ Dateien angezeigt werden und weil keiner zur Anfangszeit irgendwelche Rechte hatte. |
| Warum kann eine Datei mit chmod 660 trotzdem für dich unlesbar sein, obwohl du nicht „Andere“ bist? | Weil die Gruppe noch nicht geladen wurde.                                                                           |

**6 · Reflexion**

*Was war heute am schwierigsten zu verstehen, und warum?*

War eine gute Wiederholung.

*Was hast du heute neu gelernt, das dir vorher nicht klar war?*

Die Oktalwerte von chmod.

*Wobei hättest du dir mehr Zeit oder Hilfe gewünscht?*

Nirgendwo.
