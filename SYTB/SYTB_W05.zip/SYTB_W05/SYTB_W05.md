**SYTB – Systemtechnik Betriebssysteme**

3\. Jahrgang · HTL Krems

| **Woche / Station** | **Datum** |
|---------------------|-----------|
| Woche 5             | 16.10.26  |

**1 · Aufgabenstellung**

*Worum ging es in dieser Einheit? Ein bis zwei Sätze reichen – z. B. Titel und Kernthema des Arbeitsblatts.*

Apache

**2 · Ergebnisse**

*Screenshot(s) oder Beispiel-Ausgaben, die dein Ergebnis zeigen – z. B. ls -la deines Ordners, deine IP-Adresse, dein Levelstand in GameShell, der Name deines Snapshots. Screenshot einfach hier einfügen (Bild einfügen, oder per Copy-Paste).*

Aufgabe 1:

<img src="images/image1.png" style="width:6.925in;height:2.32431in" />

Aufgabe 2:

<img src="images/image2.png" style="width:6.925in;height:3.34236in" />

(-\>) ist eine Verknüpfung

<img src="images/image3.png" style="width:6.925in;height:0.51111in" />

Aufgabe 3: 404

<img src="images/image4.png" style="width:3.95889in;height:1.57314in" />

<img src="images/image5.png" style="width:5.1153in;height:1.07307in" />

403

<img src="images/image6.png" style="width:3.80261in;height:1.54188in" />

Aufgabe 4:

<img src="images/image7.png" style="width:5.47993in;height:1.22934in" />

<img src="images/image8.png" style="width:6.925in;height:0.35486in" />

<img src="images/image9.png" style="width:6.77178in;height:0.36463in" />

<img src="images/image10.png" style="width:6.925in;height:2.88819in" />

<img src="images/image11.png" style="width:6.925in;height:1.18958in" />

**3 · Kontrollfragen & Antworten**

*Übernimm die Kontrollfragen aus dem Arbeitsblatt dieser Woche und beantworte sie hier in eigenen Worten.*

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Frage</strong></th>
<th><strong>Antwort</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>Deine Anfrage geht an Port 8080 deines Laptops, Apache wartet aber auf Port 80 in der VM. Wer sorgt dafür, dass sie trotzdem ankommt?</td>
<td>Die Port-Weiterleitung.</td>
</tr>
<tr class="even">
<td>Was ist der Unterschied zwischen sites-available und sites-enabled? Warum wird beim Ausschalten keine Datei gelöscht?</td>
<td><p>Sites-available verfügbare Seiten</p>
<p>Sites-enabled Die Seite die gerade freigeschalten ist.</p></td>
</tr>
<tr class="odd">
<td>Warum bekommst du in Schritt 2 den Code 403 und nicht 404? Wer ist für Apache „die Anderen“?</td>
<td><p>403 Verboten</p>
<p>404 existiert nicht.</p>
<p>Prinzipiell jeder der von einer fremden Maschine zugreifen will.</p></td>
</tr>
<tr class="even">
<td>Was steht in einer Zeile des access.log? Nenne mindestens 4 Angaben.</td>
<td>http protokoll, Statuscode, Browser, Betriebssystem</td>
</tr>
<tr class="odd">
<td>Wo suchst du bei 404, wo bei 403?</td>
<td>Im access.log. Richtige Fehler sind im error.log.</td>
</tr>
</tbody>
</table>

**4 · Reflexion**

*Was war heute am schwierigsten zu verstehen, und warum?*

Hat alles gepasst.

*Was hast du heute neu gelernt, das dir vorher nicht klar war?*

Wie man logs in Echtzeit laufen lässt.

*Wobei hättest du dir mehr Zeit oder Hilfe gewünscht?*

Nirgendwo.
